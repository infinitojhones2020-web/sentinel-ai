from datetime import datetime,timedelta,timezone
from jose import jwt,JWTError
from argon2 import PasswordHasher
from argon2.exceptions import VerifyMismatchError
from app.core.config import settings
_ph=PasswordHasher()
def hash_password(password:str)->str: return _ph.hash(password)
def verify_password(plain:str,hashed:str)->bool:
    try: return _ph.verify(hashed,plain)
    except VerifyMismatchError: return False
def create_access_token(subject:str)->str:
    now=datetime.now(timezone.utc)
    payload={'sub':subject,'iat':now,'exp':now+timedelta(minutes=settings.access_token_expire_minutes),'type':'access'}
    return jwt.encode(payload,settings.secret_key,algorithm=settings.jwt_algorithm)
def decode_access_token(token:str)->dict:
    try: return jwt.decode(token,settings.secret_key,algorithms=[settings.jwt_algorithm])
    except JWTError as exc: raise ValueError('invalid token') from exc
