from app.modules.behavior.risk import assess_behavior
from app.modules.night.engine import classify_scene,NightMode
from app.modules.anti_blinding.engine import assess_blinding
from app.modules.video.ring_buffer import RingBuffer
def test_risk():
    a=assess_behavior(repeated_passages=3,loitering_seconds=45,in_gate_zone=True,night=True); assert a.score>=60
def test_headlight(): assert classify_scene(80,0.25)==NightMode.HEADLIGHT
def test_blinding(): assert assess_blinding(0.25,0.5).detected
def test_buffer():
    b=RingBuffer(seconds=1,fps_hint=2); b.push('a',1); b.push('b',2); b.push('c',3); assert [x.frame for x in b.snapshot()]==['b','c']
