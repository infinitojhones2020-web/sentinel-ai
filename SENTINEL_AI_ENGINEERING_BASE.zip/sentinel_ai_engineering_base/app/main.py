from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.core.config import settings
from app.db.base import init_db
from app.api.v1.routers import health,events
app=FastAPI(title=settings.branding_name,version='0.1.0')
app.add_middleware(CORSMiddleware,allow_origins=[x.strip() for x in settings.cors_origins.split(',') if x.strip()],allow_credentials=True,allow_methods=['GET','POST','PUT','PATCH','DELETE'],allow_headers=['Authorization','Content-Type'])
@app.on_event('startup')
async def startup(): settings.storage_path.mkdir(parents=True,exist_ok=True); await init_db()
app.include_router(health.router,prefix='/api/v1'); app.include_router(events.router,prefix='/api/v1')
@app.get('/')
async def root(): return {'name':settings.branding_name,'status':'engineering-base','docs':'/docs'}
