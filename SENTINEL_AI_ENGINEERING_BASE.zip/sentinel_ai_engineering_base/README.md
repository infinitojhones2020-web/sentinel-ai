# Sentinel AI — Engineering Base
Base para uma central de vigilância inteligente 24h, local-first.

## Implementado
FastAPI, SQLite async, entidades mínimas, health, scoring explicável, ring buffer, night/anti-blinding heurísticos, Argon2/JWT, scripts Windows e testes básicos.

## Ainda não implementado
ONVIF real, RTSP/PyAV real, gravação, detector ONNX, tracking, face/re-ID, OCR de placas, multi-câmera, clima, notificações, realtime WebSocket, UI final e app mobile.

Leia docs/CODEX_HANDOFF.md.
