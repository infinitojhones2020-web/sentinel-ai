from fastapi import APIRouter
from pydantic import BaseModel
from app.services.virtual_guard import VirtualGuard
router=APIRouter(prefix='/events',tags=['events']); guard=VirtualGuard()
class EventInput(BaseModel):
    repeated_passages:int=0; loitering_seconds:int=0; in_gate_zone:bool=False; in_restricted_zone:bool=False; night:bool=False; camera_blinded:bool=False
@router.post('/evaluate')
async def evaluate_event(payload:EventInput): return guard.evaluate(payload.model_dump())
