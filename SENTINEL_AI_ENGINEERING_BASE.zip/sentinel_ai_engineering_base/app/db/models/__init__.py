from .entities import Camera, Event, PersonEntity, VehicleEntity, PlateObservation
