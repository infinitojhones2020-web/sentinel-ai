$ErrorActionPreference="Stop"
$Root=Split-Path -Parent $PSScriptRoot
Set-Location $Root
if (-not (Test-Path ".venv")) { py -3.12 -m venv .venv }
& ".\.venv\Scripts\python.exe" -m pip install --upgrade pip
& ".\.venv\Scripts\pip.exe" install -r requirements\base.txt -r requirements\ai.txt -r requirements\dev.txt
if (-not (Test-Path ".env")) { Copy-Item ".env.example" ".env" }
