# Threat Model
Atacante na LAN, câmera comprometida, stream malformado, roubo de token, path traversal, injection, exfiltração de biometria/vídeo, adulteração de eventos, ransomware, disco cheio e DoS por excesso de eventos.
