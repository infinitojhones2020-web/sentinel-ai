# Security
Local-only por padrão; credenciais de câmera criptografadas; Argon2; JWT curto; RBAC; auditoria; sem RTSP/ONVIF exposto à internet; remote somente via TLS/VPN/túnel seguro.
