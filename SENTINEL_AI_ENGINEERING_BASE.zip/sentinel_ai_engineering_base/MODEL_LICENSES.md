# Model Licenses
Nenhum peso incluso. Antes de adicionar qualquer modelo: verificar licença do artefato exato, uso comercial, origem, versão e SHA256.
