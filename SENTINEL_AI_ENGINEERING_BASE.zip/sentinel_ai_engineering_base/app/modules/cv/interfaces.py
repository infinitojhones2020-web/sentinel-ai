from abc import ABC,abstractmethod
from typing import Any
import numpy as np
class DetectorInterface(ABC):
    @abstractmethod
    def detect(self,frame:np.ndarray)->list[dict[str,Any]]: ...
class TrackerInterface(ABC):
    @abstractmethod
    def update(self,detections:list[dict[str,Any]],frame:np.ndarray)->list[dict[str,Any]]: ...
class FaceEmbedderInterface(ABC):
    @abstractmethod
    def get_embedding(self,face_crop:np.ndarray)->np.ndarray|None: ...
class PlateOCRInterface(ABC):
    @abstractmethod
    def read(self,plate_crop:np.ndarray)->dict[str,Any]: ...
