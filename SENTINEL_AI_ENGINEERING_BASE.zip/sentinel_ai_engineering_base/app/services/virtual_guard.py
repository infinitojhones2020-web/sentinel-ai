from app.modules.behavior.risk import assess_behavior
class VirtualGuard:
    def evaluate(self,event:dict)->dict:
        a=assess_behavior(repeated_passages=int(event.get('repeated_passages',0)),loitering_seconds=int(event.get('loitering_seconds',0)),in_gate_zone=bool(event.get('in_gate_zone',False)),in_restricted_zone=bool(event.get('in_restricted_zone',False)),night=bool(event.get('night',False)),camera_blinded=bool(event.get('camera_blinded',False)))
        return {'score':a.score,'level':a.level,'reasons':a.reasons}
