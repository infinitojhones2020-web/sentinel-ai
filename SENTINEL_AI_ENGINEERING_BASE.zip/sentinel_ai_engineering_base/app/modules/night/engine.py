from enum import StrEnum
class NightMode(StrEnum): DAY='DAY'; LOW_LIGHT='LOW_LIGHT'; NIGHT_IR='NIGHT_IR'; HEADLIGHT='HEADLIGHT'; RAIN_NIGHT='RAIN_NIGHT'
def classify_scene(mean_luma:float,saturated_ratio:float,raining:bool=False)->NightMode:
    if saturated_ratio>0.20: return NightMode.HEADLIGHT
    if mean_luma<25: return NightMode.RAIN_NIGHT if raining else NightMode.NIGHT_IR
    if mean_luma<55: return NightMode.LOW_LIGHT
    return NightMode.DAY
