# Architecture
Cameras -> Discovery -> Video Ingest -> Ring Buffer -> Detection -> Tracking -> Person/Face/Vehicle/Plate -> Temporal/Behavior -> Virtual Guard -> Events -> Storage/DB -> Notifications/API/Web/Mobile.
