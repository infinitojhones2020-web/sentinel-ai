# Privacy
Rostos e embeddings são dados biométricos sensíveis. Padrão: processamento local, retenção configurável, exclusão e auditoria. Não usar características protegidas para scoring de risco.
