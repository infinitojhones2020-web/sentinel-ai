from fastapi import APIRouter
router=APIRouter(tags=['health'])
@router.get('/health')
async def health(): return {'status':'ok','components':{'api':'ok','camera_discovery':'scaffolded','video_ingest':'scaffolded','ai':'scaffolded','virtual_guard':'implemented_core'}}
