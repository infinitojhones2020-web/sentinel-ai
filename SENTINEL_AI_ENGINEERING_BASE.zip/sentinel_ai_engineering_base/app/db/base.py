from sqlalchemy.ext.asyncio import AsyncSession,async_sessionmaker,create_async_engine
from sqlalchemy.orm import DeclarativeBase
from app.core.config import settings
class Base(DeclarativeBase): pass
engine=create_async_engine(settings.database_url,future=True)
SessionLocal=async_sessionmaker(engine,expire_on_commit=False,class_=AsyncSession)
async def init_db():
    from app.db import models
    async with engine.begin() as conn: await conn.run_sync(Base.metadata.create_all)
