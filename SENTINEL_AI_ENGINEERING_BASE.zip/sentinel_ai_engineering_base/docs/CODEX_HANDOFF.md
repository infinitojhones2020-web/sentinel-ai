# CODEX HANDOFF

## IMPLEMENTED
- FastAPI/config/env
- SQLite async + entidades mínimas
- /api/v1/health
- /api/v1/events/evaluate
- VirtualGuard inicial + scoring explicável
- RingBuffer
- Night mode e AntiBlinding heurísticos
- Argon2/JWT
- scripts Windows e testes básicos

## SCAFFOLDED
- CameraProviderInterface
- interfaces CV
- estrutura modular

## NOT_IMPLEMENTED
- ONVIF discovery real
- RTSP/PyAV
- recording/pre-post clips
- detector ONNX real
- tracking real
- face/re-ID
- vehicle re-ID
- plate OCR temporal
- cross-camera correlation
- weather fusion
- realtime WebSocket
- UI final
- mobile app
- remote access
- push notifications
- PTZ real

## ORDEM PARA O CODEX
1 hardware/doctor
2 ONVIF+RTSP
3 VideoStreamManager/reconnect/watchdog
4 recording+buffer
5 detector ONNX
6 tracker
7 person/vehicle temporal memory
8 face quality+embedding+re-ID
9 plate OCR consensus
10 weather/night/anti-blinding
11 cross-camera
12 notifications
13 WebSocket+UI
14 auth/RBAC/remote
15 mobile API/app
16 hostile/E2E tests
