# API Reference
Swagger: http://127.0.0.1:8088/docs
Health: http://127.0.0.1:8088/api/v1/health
