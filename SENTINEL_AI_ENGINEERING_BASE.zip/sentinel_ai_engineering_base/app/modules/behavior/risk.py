from dataclasses import dataclass
@dataclass(frozen=True)
class RiskAssessment: score:int; level:str; reasons:list[str]
def assess_behavior(*,repeated_passages:int=0,loitering_seconds:int=0,in_gate_zone:bool=False,in_restricted_zone:bool=False,night:bool=False,camera_blinded:bool=False)->RiskAssessment:
    score=0; reasons=[]
    if repeated_passages>=3: score+=20; reasons.append('repeated_passage')
    if loitering_seconds>=30: score+=25; reasons.append('loitering')
    if in_gate_zone: score+=10; reasons.append('gate_zone')
    if in_restricted_zone: score+=35; reasons.append('restricted_zone')
    if night: score+=10; reasons.append('night_time')
    if camera_blinded: score+=35; reasons.append('camera_blinding')
    score=min(100,score)
    level='NORMAL' if score<20 else 'OBSERVE' if score<40 else 'ATTENTION' if score<60 else 'HIGH_ATTENTION' if score<80 else 'CRITICAL'
    return RiskAssessment(score,level,reasons)
