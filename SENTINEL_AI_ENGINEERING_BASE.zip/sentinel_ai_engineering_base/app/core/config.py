from pathlib import Path
from pydantic_settings import BaseSettings, SettingsConfigDict
class Settings(BaseSettings):
    branding_name: str='Sentinel AI'
    host: str='127.0.0.1'
    port: int=8088
    database_url: str='sqlite+aiosqlite:///./data/sentinel.db'
    storage_path: Path=Path('./data')
    secret_key: str='CHANGE_ME_WITH_A_RANDOM_64_CHAR_SECRET'
    camera_credential_key: str|None=None
    jwt_algorithm: str='HS256'
    access_token_expire_minutes: int=30
    cors_origins: str='http://127.0.0.1:8088,http://localhost:8088'
    log_level: str='INFO'
    model_config=SettingsConfigDict(env_file='.env',env_file_encoding='utf-8',extra='ignore')
settings=Settings()
