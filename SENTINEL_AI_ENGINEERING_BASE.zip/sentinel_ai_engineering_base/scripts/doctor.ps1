Write-Host "=== Sentinel AI Doctor ===" -ForegroundColor Cyan
foreach ($c in @("python","ffmpeg","git")) { $cmd=Get-Command $c -ErrorAction SilentlyContinue; if ($cmd) { Write-Host "$c : OK" -ForegroundColor Green } else { Write-Host "$c : AUSENTE" -ForegroundColor Yellow } }
Get-CimInstance Win32_ComputerSystem | Select-Object Manufacturer,Model,@{N='RAM_GB';E={[math]::Round($_.TotalPhysicalMemory/1GB,1)}}
Get-CimInstance Win32_VideoController | Select-Object Name,@{N='VRAM_GB';E={[math]::Round($_.AdapterRAM/1GB,1)}}
