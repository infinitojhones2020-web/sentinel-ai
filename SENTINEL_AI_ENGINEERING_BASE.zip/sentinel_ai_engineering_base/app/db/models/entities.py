from datetime import datetime,timezone
from sqlalchemy import String,DateTime,Integer,Float,Boolean,ForeignKey,Text
from sqlalchemy.orm import Mapped,mapped_column
from app.db.base import Base
def utcnow(): return datetime.now(timezone.utc)
class Camera(Base):
    __tablename__='cameras'; id:Mapped[int]=mapped_column(primary_key=True); name:Mapped[str]=mapped_column(String(120)); host:Mapped[str]=mapped_column(String(255)); enabled:Mapped[bool]=mapped_column(Boolean,default=True)
class Event(Base):
    __tablename__='events'; id:Mapped[int]=mapped_column(primary_key=True); camera_id:Mapped[int|None]=mapped_column(ForeignKey('cameras.id'),nullable=True); event_type:Mapped[str]=mapped_column(String(80),index=True); attention_level:Mapped[int]=mapped_column(Integer,default=0); confidence:Mapped[float|None]=mapped_column(Float,nullable=True); reasons_json:Mapped[str]=mapped_column(Text,default='[]'); created_at:Mapped[datetime]=mapped_column(DateTime(timezone=True),default=utcnow,index=True)
class PersonEntity(Base):
    __tablename__='persons'; id:Mapped[int]=mapped_column(primary_key=True); status:Mapped[str]=mapped_column(String(32),default='UNKNOWN'); visit_count:Mapped[int]=mapped_column(Integer,default=1)
class VehicleEntity(Base):
    __tablename__='vehicles'; id:Mapped[int]=mapped_column(primary_key=True); vehicle_type:Mapped[str|None]=mapped_column(String(40),nullable=True); color:Mapped[str|None]=mapped_column(String(40),nullable=True); visit_count:Mapped[int]=mapped_column(Integer,default=1)
class PlateObservation(Base):
    __tablename__='plates'; id:Mapped[int]=mapped_column(primary_key=True); vehicle_id:Mapped[int|None]=mapped_column(ForeignKey('vehicles.id'),nullable=True); plate_text:Mapped[str|None]=mapped_column(String(32),nullable=True); confidence:Mapped[float|None]=mapped_column(Float,nullable=True)
