from collections import deque
from dataclasses import dataclass
from threading import RLock
from time import time
from typing import Any
@dataclass(slots=True)
class BufferedFrame: ts:float; frame:Any
class RingBuffer:
    def __init__(self,seconds:int=15,fps_hint:int=10): self._frames=deque(maxlen=max(1,seconds*fps_hint)); self._lock=RLock()
    def push(self,frame:Any,ts:float|None=None)->None:
        with self._lock: self._frames.append(BufferedFrame(ts or time(),frame))
    def snapshot(self)->list[BufferedFrame]:
        with self._lock: return list(self._frames)
