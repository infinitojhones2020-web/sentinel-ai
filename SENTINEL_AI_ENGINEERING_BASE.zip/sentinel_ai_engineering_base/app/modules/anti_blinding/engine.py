from dataclasses import dataclass
@dataclass(frozen=True)
class BlindingAssessment: detected:bool; confidence:float; reason:str
def assess_blinding(saturated_ratio:float,luminance_jump:float)->BlindingAssessment:
    c=min(1.0,max(0.0,saturated_ratio*2.5+luminance_jump*0.5)); d=saturated_ratio>=0.18 and luminance_jump>=0.25
    return BlindingAssessment(d,c,'bright_source_saturation' if d else 'normal')
